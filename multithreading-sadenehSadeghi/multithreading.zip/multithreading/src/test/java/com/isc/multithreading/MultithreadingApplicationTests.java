package com.isc.multithreading;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultithreadingApplicationTests {

	@Test
	void contextLoads() {
	}

}
